package dns.exceptions;

public class NotPointerException extends Exception {
    public NotPointerException() { super("Not a pointer"); }
}
