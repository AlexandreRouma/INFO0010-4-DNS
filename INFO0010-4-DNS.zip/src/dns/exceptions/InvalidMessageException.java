package dns.exceptions;

public class InvalidMessageException extends Exception {
    public InvalidMessageException(String detail) { super(detail); }
}
