#!/bin/sh
BUILD_DIR=build

# Run
cd $BUILD_DIR
java Client $@